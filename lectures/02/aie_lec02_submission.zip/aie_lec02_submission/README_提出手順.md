# 第2回の提出方法

この一式は、第2回の「基礎」課題（学習回数20→10の比較）用です。

## 提出前に読むもの

`lectures/02/answer.md` が提出本文です。実測値を基に、演習と宿題の両方を記入しています。ChatGPTがColabの操作・集計・文章化を支援したことも記しています。提出前に本文と回答例を読み、理解できた内容として提出してください。講師の実行例は使っていません。

## GitHubの画面で提出する

1. https://github.com/matsuolab/lecture-ai-engineering-2026 を開きます。自分のコピーがなければ、右上の **Fork → Create fork** で作成します。
2. 自分のリポジトリで、左上の **main** を押し、`lec02` と入力して作業ブランチを作ります。既に `lec02` がある場合は、そのブランチの内容を確認してから使います。
3. `lectures/02/answer.md` を開き、鉛筆の **Edit** を押します。この一式の同名ファイルをテキストエディタで開き、本文全体をコピーして置き換えます。
4. **Commit changes** を押して `lec02` ブランチへ保存します。
5. 証拠ファイルも含める場合は、自分の `lec02` ブランチの `lectures/02/` で **Add file → Upload files** を選び、`results/` フォルダをアップロードしてコミットします。本文の数値の出所は `results/epochs20/` と `results/epochs10/` です。本文中のリンクを使うためにも、同梱を推奨します。
6. **Pull requests → New pull request** を開きます。送り先の **base repository は自分のリポジトリ**、**base は main**、**compare は lec02** を選びます。タイトル例は「第2回：LoRAの学習回数による出力形式と内容の比較」です。差分を読み、内容が合っていれば **Create pull request** で提出します。

講座元の `matsuolab` リポジトリへのPRにしないよう、base repositoryを確認してください。課題の案内は「自分のforkの中で作業ブランチ→main」です。

## 内容を理解するための短い説明

- **LoRA**：基盤モデルを固定し、追加した小さな行列だけを学習する方法です。
- **format_rate**：`answer`（文字列）と`needs_review`（真偽値）だけを持つJSONを出せた割合です。
- **content_rate**：`needs_review`が正解と一致し、回答に必須語句が含まれた割合です。一般的な読解能力全体を表す値ではありません。
- **needs_review**：FAQに根拠がない場合に、確認が必要だと知らせるフラグです。
- **loss**：学習例に対する誤差です。小さくても、未知の質問への正答が保証されるわけではありません。

## 再実行する場合

`notebooks/lec02_epochs20_rerun.ipynb` と `notebooks/lec02_epochs10_rerun.ipynb` をColabで開き、T4 GPUを指定して上から実行します。条件を変える前に **ランタイム → セッションを再起動** を実行してください。データ・モデル・生成条件は同じで、学習回数だけを変えています。最後のセルが結果ZIPをダウンロードします。

モデル重みやadapterの大きなファイルは提出一式に含めていません。実行済みノートブック、設定、評価出力、学習ログから結果を追えます。

課題案内：https://github.com/matsuolab/lecture-ai-engineering-2026/blob/main/lectures/02/problem.md
